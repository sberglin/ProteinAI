##' @S3method vcov cumres
vcov.cumres <- function(object,...) object$vcov
