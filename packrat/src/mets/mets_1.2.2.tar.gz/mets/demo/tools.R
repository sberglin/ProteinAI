
example(fast.reshape)

example(fast.approx)

example(fast.pattern)

example(lifetable)

