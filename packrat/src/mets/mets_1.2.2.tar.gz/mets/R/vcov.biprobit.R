##' @export
vcov.biprobit <- function(object,...) object$vcov
