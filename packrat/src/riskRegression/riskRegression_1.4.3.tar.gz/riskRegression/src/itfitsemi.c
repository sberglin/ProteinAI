#include <stdio.h>
#include <math.h>
#include "riskregression.h"


